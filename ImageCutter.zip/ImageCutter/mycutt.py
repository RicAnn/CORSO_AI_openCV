import cv2 as cv
import mylib as pr1

X = 800
Y = 600
#ridimensioono l'immagine
myimg = pr1.ridimensiona_immagine(pr1.test_img, X, Y)
pr1.visualizza_immagine(myimg)

#ridimensioono l'immagine e la 
#trasformo in scala di grigio l'immagine rgb
resized = pr1.ridimensiona_immagine(pr1.test_img, X, Y)
myimg = pr1.grigio(resized)
pr1.visualizza_immagine(myimg)

#METODO 2: ridimensioono l'immagine e la 
#trasformo in scala di grigio l'immagine rgb
myimg = pr1.grigio_e_ridimensiona_immagine(pr1.test_img, X-100, Y-100)
pr1.visualizza_immagine(myimg)

#METODO 3: Restituisco 2 immagini
img_gray, resized_rgb = pr1.grigio_piu_ridimensiona_immagine(pr1.test_img, X-200, Y-200) 
pr1.visualizza_immagini(resized_rgb, img_gray)

#Utilizzo un'altra conversione dell'immagine
myimg = pr1.altraConversione(pr1.test_img)
pr1.visualizza_immagine(myimg)

#disegnamo un rettangolo sull'immagine

#myimg = pr1.draw_rect(pr1.test_img, (100, 100, 200, 200))
# myimg = pr1.grigio(pr1.test_img)
# myimg2 = pr1.ridimensiona_immagine(myimg, X, Y)
# img1 = pr1.draw_rect(myimg2, (100, 100, 200, 200))



# Disegno alcune forme sull'immagine
#myimg = pr1.draw_rect(pr1.test_img, (100, 100, 200, 200))

resized = cv.resize(pr1.test_img, (800,600))
cv.putText(resized, "Mattarella", (50,50),cv.QT_FONT_NORMAL, 1,(0,0,255),3)
cv.rectangle(resized,(60,60), (600+100,60+100), (0,0,255), thickness=5)
cv.line(resized,(0,0), (799,599), (90,180,55), thickness=5, lineType=cv.LINE_AA)
cv.line(resized,(799,0), (0,599), (90,180,55), thickness=5, lineType=cv.LINE_AA)
cv.circle(resized, (100,300), 50, (255,0,0), thickness=5, lineType=cv.LINE_AA)
cv.ellipse(resized, (400,300), (50,100), 0, 0, 280, (0,255,0), thickness=5, lineType=cv.LINE_AA)    
pr1.visualizza_immagine(resized)
  
# individuo il viso e disegno un rettangolo attorno ad esso
resized = cv.resize(pr1.test_img, (800,600))
face, gray = pr1.faceDetection(resized)
cv.rectangle(resized,(230,181), (230+331,181+331), (0,0,255), thickness=5)
pr1.visualizza_immagine(resized)

# ridimensiono l'immagine e la taglio lasciando solo il viso    
resized = cv.resize(pr1.test_img, (800,600))
face, gray = pr1.faceDetection(resized)
cutted = pr1.taglia_immagine(resized, face[0])
pr1.visualizza_immagine(cutted)
