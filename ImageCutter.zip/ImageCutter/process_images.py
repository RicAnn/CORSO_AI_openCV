import os
import cv2 as cv
from mylib import faceDetection, taglia_immagine

def process_images(input_folder, output_folder):
    # Crea la cartella di output se non esiste
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # Itera su tutti i file nella cartella di input
    for filename in os.listdir(input_folder):
        filepath = os.path.join(input_folder, filename)
        if os.path.isfile(filepath):
            # Leggi l'immagine
            img = cv.imread(filepath)
            if img is not None:
                # Applica il rilevamento dei volti
                faces, _ = faceDetection(img)
                for i, face in enumerate(faces):
                    # Ritaglia il volto
                    print("Face detected:", face)
                    cropped_face = taglia_immagine(img, face)
                    # Salva l'immagine ritagliata
                    output_path = os.path.join(output_folder, f"{os.path.splitext(filename)[0]}_face{i+1}.jpg")
                    # ridimensiona l'immagine ritagliata
                    cropped_face = cv.resize(cropped_face, (300, 300))
                    cv.imwrite(output_path, cropped_face)

# Esempio di utilizzo
input_folder = r"input_images"
output_folder = r"output_images"
process_images(input_folder, output_folder)