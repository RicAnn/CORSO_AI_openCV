import cv2 as cv
import os
import numpy as np

test_img = cv.imread(r"immagini\m4.jpg")

def ridimensiona_immagine(img, x, y):
    resized = cv.resize(img, (x,y))
    return resized

def grigio(img):
    #trasformo in scala di grigio l'immagine rgb
    gray=cv.cvtColor(img, cv.COLOR_BGR2GRAY)
    return gray

def altraConversione(img):
    #trasformo in scala di grigio l'immagine rgb COLOR_BGR2HSV_FULL  COLOR_BGR2LUV COLOR_HSV2RGB COLOR_BGR2YUV
    #COLOR_BGR2YCrCb COLOR_BGR2XYZ COLOR_BGR2Lab COLOR_BGR2Luv COLOR_BGR2HLS COLOR_BGR2YUV
    img_color=cv.cvtColor(img, cv.COLOR_BGR2YUV)
    return img_color

def grigio_e_ridimensiona_immagine(img, x, y):
    #ridimensioono l'immagine e la 
    #trasformo in scala di grigio l'immagine rgb
    resized = cv.resize(img, (x,y))
    gray=cv.cvtColor(resized, cv.COLOR_BGR2GRAY)
    #restituisco solo l'immagine finale
    return gray

def grigio_piu_ridimensiona_immagine(img, x, y):
    #ridimensioono l'immagine e la 
    #trasformo in scala di grigio l'immagine rgb
    resized = cv.resize(img, (x,y))
    gray=cv.cvtColor(resized, cv.COLOR_BGR2GRAY)
    #restituisco solo l'immagine finale
    return gray, resized

def visualizza_immagine(img):
    cv.imshow("MATTARELLA", img)
    cv.waitKey(0)
    cv.destroyAllWindows()

def visualizza_immagini(img, img2):
    cv.imshow("RGB - MATTARELLA", img)
    cv.imshow("Gray - MATTARELLA", img2)
    cv.waitKey(0)
    cv.destroyAllWindows()

def draw_rect(test_img, face):
    (x,y,w,h) = face
    print("x", x)
    print("y", y)       
    print("w", w)
    print("h", h)
    #disegno un rettangolo sull'immagine
    cv.rectangle(test_img,(x,y), (x+w,y+h), (0,0,255), thickness=5)

def put_name(test_img, text, x, y):
    cv.putText(test_img, text, (x,y),cv.QT_FONT_NORMAL,2,(0,0,255),3)


def faceDetection(img):
    #trasformo l'immagine da colori a scala di grigio
    gray=cv.cvtColor(img,cv.COLOR_BGR2GRAY)
    #applico il filtro per il riconoscimento frontale del viso
    #il file xml è presente nella cartella data di opencv, ma può essere scaricato anche da internet
    
    haar_face = cv.CascadeClassifier(r"C:\Users\ricca\Documents\PYTHON\MachineLearning\opencv-master\data\haarcascades\haarcascade_frontalface_default.xml")
    #applico il filtro sul viso, con i parametri di scala e vicinanza
    #scaleFactor: quanto ridurre l'immagine ad ogni passaggio
    #minNeighbors: numero di vicini che deve avere un rettangolo per essere considerato un viso 
    #minSize: dimensione minima del rettangolo
    #maxSize: dimensione massima del rettangolo 
    #face = haar_face.detectMultiScale(gray,scaleFactor=1.1,minNeighbors=5,minSize=(30,30),maxSize=(100,100))
    face = haar_face.detectMultiScale(gray,scaleFactor=1.3,minNeighbors=5)
    print("face", face)
    return face, gray

def taglia_immagine(img, face):
    #estrapolo le coordinate
    (x,y,w,h) = face
    # e prelevo la regione del viso
    region  = img[y:y+h, x:x+w]
    return region